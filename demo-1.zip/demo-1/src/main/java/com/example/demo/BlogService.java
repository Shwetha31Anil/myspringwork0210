package com.example.demo;

import java.util.List;

public interface BlogService {
	public void addBlog(Blog b);
	public Iterable<Blog> getAll();
	public List<Blog> getByContent(String content);
}
