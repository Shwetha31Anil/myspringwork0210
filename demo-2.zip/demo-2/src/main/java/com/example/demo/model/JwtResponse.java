package com.example.demo.model;

import java.io.Serializable;

public class JwtResponse  implements Serializable{

	private  final String jwttoken;

	public JwtResponse(String jwttoken) {
		// TODO Auto-generated constructor stub
		this.jwttoken=jwttoken;
	}
	
	public String getJwttoken() {
		return jwttoken;
	}
	
}
