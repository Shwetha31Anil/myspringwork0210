package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootExampleKeycloakApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootExampleKeycloakApplication.class, args);
	}

}
