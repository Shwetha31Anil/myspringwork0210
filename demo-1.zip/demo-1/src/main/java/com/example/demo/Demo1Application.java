package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
//@ComponentScan(basePackages = "")
public class Demo1Application {
	//@Configuration--- @Bean DataSource, HikariDataSource, LocalSessionFactoryBean, EntityManager,InternalResourceViewResolver
	//@ComponenetScan
	//@EnableWebMvc
	//@EnableTransactionManagement
	//@EnableAspectJAutoProxy
	// ----@Controller--view   @RestController--json
	public static void main(String[] args) {
		SpringApplication.run(Demo1Application.class, args);
	}
	
	/*
	 * <servelt> <servlet-name>dispatcher <servlet-class>DispatcherServlet
	 * <init-param> <param-name> <param-value>location of configuration xml or java
	 * </servlet> <servlet-mapping> <servlet-name> <url-pattern>/
	 */
}

