package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class Blog{
	@Id
	private int bid;
	private String bcontent;
	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public String getBcontent() {
		return bcontent;
	}
	public void setBcontent(String bcontent) {
		this.bcontent = bcontent;
	}
	
}
