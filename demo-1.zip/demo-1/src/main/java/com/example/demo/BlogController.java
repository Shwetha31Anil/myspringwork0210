package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/blogs")
public class BlogController {
	
	@Autowired
	BlogService blogService;
	
	@PostMapping("")
	public void addBlog(@RequestBody Blog b) {
		blogService.addBlog(b);
	}
	
	@RequestMapping("")
	public Iterable<Blog> getAll(){
		return blogService.getAll();
	}
	
	@RequestMapping("/{content}")
	public List<Blog> getByContent(@PathVariable("content")String content){
		return blogService.getByContent(content);
	}

}
