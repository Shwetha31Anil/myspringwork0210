package com.example.demo.services;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import java.util.ArrayList;

@Service
public class JwtUserDetailService implements UserDetailsService {

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		if("Shwetha".equals(username)) {
			return new User("Shwetha","$2a$10$CZfzNHHLpuiYSK8OqJXVDuj3o0eI4qzt2F44H02ww70aegllqMqya",new ArrayList<>());
		}else {
			throw new UsernameNotFoundException("User not found");
		}
		
	}

}
