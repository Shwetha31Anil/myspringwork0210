package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BlogServiceImpl implements BlogService {
	@Autowired
	BlogRepository blogRepository;

	@Override
	public void addBlog(Blog b) {
		blogRepository.save(b);
//		if(b.getBcontent().matches("[A-Za-z0-9]{,35}")) {
//			blogRepository.save(b);
//		}else {
//			throw new RuntimeException("Invalid Blog content");
//		}

	}

	@Override
	public Iterable<Blog> getAll() {
		
		return blogRepository.findAll();
	}

	@Override
	public List<Blog> getByContent(String content) {
		// TODO Auto-generated method stub
		return blogRepository.findByContent(content);
	}

}
