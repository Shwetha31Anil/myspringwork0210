package com.example.demo.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoController {

	@RequestMapping({"/hello"})
	public String firstPage() {
		return "Welcome to Spring Boot JWT";
		//2 opertaions
		// Generting a JWT
		// Validation JWT
		//JWTRequestFilter-- OncePerRequestFilter
		//Authentication Controller
		//AuthenticationManages
		//Service
		//JwtTokenUtil
	}
}
